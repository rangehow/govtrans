"""Bounded, coalescing process-local lanes for reconstructible refresh work.

Entry point: :class:`BoundedCoalescingLane`.  Project status, watch, and
conversation-summary owners use it for best-effort refreshes whose durable
source can always be read again.  The lane bounds unique queued scopes,
coalesces updates that target an active scope, and exposes saturation metrics.
"""

from __future__ import annotations

import logging
import queue
import threading
from collections.abc import Callable, Hashable
from typing import Generic, TypeVar


Key = TypeVar('Key', bound=Hashable)
Payload = TypeVar('Payload')
_MISSING = object()
logger = logging.getLogger(__name__)


class BoundedCoalescingLane(Generic[Key, Payload]):
    """Run at most ``workers`` consumers with a finite pending-scope queue.

    ``capacity`` bounds keys waiting behind workers.  At most
    ``capacity + workers`` unique scopes are resident because an active key
    stays tracked until all updates submitted during its run are consumed.
    """

    def __init__(
        self,
        *,
        name: str,
        workers: int,
        capacity: int,
        merge: Callable[[Payload, Payload], Payload],
        consume: Callable[[Key, Payload], None],
        on_error: Callable[[Key, Exception], None] | None = None,
    ) -> None:
        self.name = str(name)
        self.workers = max(1, int(workers))
        self.capacity = max(1, int(capacity))
        self._merge = merge
        self._consume = consume
        self._on_error = on_error
        self._queue: queue.Queue[Key] = queue.Queue(maxsize=self.capacity)
        self._condition = threading.Condition()
        self._pending: dict[Key, Payload] = {}
        self._tracked: set[Key] = set()
        self._started = False
        self._accepted = 0
        self._coalesced = 0
        self._rejected = 0
        self._peak_scopes = 0

    def submit(self, key: Key, payload: Payload) -> bool:
        """Accept or coalesce one scope without ever blocking the caller."""
        with self._condition:
            self._start_locked()
            if key in self._tracked:
                current = self._pending.get(key, _MISSING)
                self._pending[key] = (
                    payload if current is _MISSING
                    else self._merge(current, payload)  # type: ignore[arg-type]
                )
                self._coalesced += 1
                self._condition.notify_all()
                return True

            self._pending[key] = payload
            self._tracked.add(key)
            try:
                self._queue.put_nowait(key)
            except queue.Full:
                self._pending.pop(key, None)
                self._tracked.discard(key)
                self._rejected += 1
                rejected = self._rejected
                if rejected & (rejected - 1) == 0:
                    logger.warning(
                        '[%s] refresh lane saturated capacity=%d '
                        'rejected_total=%d',
                        self.name, self.capacity, rejected,
                    )
                return False
            self._accepted += 1
            self._peak_scopes = max(self._peak_scopes, len(self._tracked))
            self._condition.notify_all()
            return True

    def wait_idle(self, timeout: float = 5.0) -> bool:
        """Wait for all accepted scopes; diagnostics and clean shutdown only."""
        with self._condition:
            return self._condition.wait_for(
                lambda: not self._tracked,
                timeout=max(0.0, float(timeout)),
            )

    def snapshot(self) -> dict[str, int | str]:
        """Return bounded-lane counters without exposing mutable internals."""
        with self._condition:
            return {
                'name': self.name,
                'workers': self.workers,
                'capacity': self.capacity,
                'queued': self._queue.qsize(),
                'trackedScopes': len(self._tracked),
                'pendingScopes': len(self._pending),
                'peakScopes': self._peak_scopes,
                'accepted': self._accepted,
                'coalesced': self._coalesced,
                'rejected': self._rejected,
            }

    def _start_locked(self) -> None:
        if self._started:
            return
        for index in range(self.workers):
            threading.Thread(
                target=self._worker,
                name=f'{self.name}-{index + 1}',
                daemon=True,
            ).start()
        self._started = True

    def _worker(self) -> None:
        while True:
            key = self._queue.get()
            try:
                while True:
                    with self._condition:
                        payload = self._pending.pop(key, _MISSING)
                        if payload is _MISSING:
                            self._tracked.discard(key)
                            self._condition.notify_all()
                            break
                    try:
                        self._consume(key, payload)  # type: ignore[arg-type]
                    except Exception as exc:
                        if self._on_error is not None:
                            self._on_error(key, exc)
                        else:
                            logger.exception(
                                '[%s] refresh consumer failed key=%r',
                                self.name, key,
                            )
            finally:
                self._queue.task_done()
