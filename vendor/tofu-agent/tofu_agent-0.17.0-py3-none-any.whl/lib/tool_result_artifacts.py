"""Owner-scoped repository for reconstructible large tool results.

Application code uses semantic Sidecar operations only. Filesystem paths and
SQL never cross this boundary, keeping SQLite/PostgreSQL swappable.
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from typing import Any

from lib.storage import get_storage_client


DEFAULT_TTL_MS = 24 * 60 * 60 * 1000
MAX_TTL_MS = 7 * 24 * 60 * 60 * 1000


def _owner(user_id: int) -> int:
    value = int(user_id)
    if value <= 0:
        raise ValueError("user_id must be a positive repository owner")
    return value


@dataclass(frozen=True)
class ToolResultArtifactRepository:
    """Stateless semantic repository; ownership is explicit on every call."""

    deadline_seconds: float = 5.0

    def put(self, *, user_id: int, content: str,
            media_type: str = "text/plain", ttl_ms: int = DEFAULT_TTL_MS,
            now_ms: int | None = None) -> dict[str, Any]:
        owner = _owner(user_id)
        now = int(now_ms or time.time() * 1000)
        ttl = max(1, min(int(ttl_ms), MAX_TTL_MS))
        payload = {
            "user_id": owner,
            "content": str(content),
            "media_type": str(media_type or "text/plain"),
            "created_at_ms": now,
            "expires_at_ms": now + ttl,
        }
        digest = hashlib.sha256(
            str(content).encode("utf-8", errors="replace")).hexdigest()
        command_id = f"tool-result:{owner}:{digest}:{now + ttl}"
        return get_storage_client(write=True).command(
            "tool_result_artifact.put", payload, command_id,
            deadline=self.deadline_seconds,
        )

    def read_range(self, *, user_id: int, artifact_ref: str,
                   offset: int = 0, limit: int = 8192,
                   now_ms: int | None = None) -> dict[str, Any] | None:
        return get_storage_client().query(
            "tool_result_artifact.read",
            {
                "user_id": _owner(user_id),
                "artifact_ref": str(artifact_ref),
                "offset": max(0, int(offset)),
                "limit": max(1, min(int(limit), 64 * 1024)),
                "now_ms": int(now_ms or time.time() * 1000),
            },
            deadline=self.deadline_seconds,
        )

    def search(self, *, user_id: int, artifact_ref: str, query: str,
               cursor: int = 0, limit: int = 8,
               now_ms: int | None = None) -> dict[str, Any] | None:
        return get_storage_client().query(
            "tool_result_artifact.search",
            {
                "user_id": _owner(user_id),
                "artifact_ref": str(artifact_ref),
                "query": str(query),
                "cursor": max(0, int(cursor)),
                "limit": max(1, min(int(limit), 20)),
                "now_ms": int(now_ms or time.time() * 1000),
            },
            deadline=self.deadline_seconds,
        )


__all__ = [
    "DEFAULT_TTL_MS", "MAX_TTL_MS", "ToolResultArtifactRepository",
]
