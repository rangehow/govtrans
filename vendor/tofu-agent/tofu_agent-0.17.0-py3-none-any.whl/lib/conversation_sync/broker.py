"""Low-latency wakeup broker for the durable conversation change log.

The broker never carries projection authority.  Local storage ACKs and
cross-replica push frames merely wake an SSE reader, which then replays the
ordered database log.  Missing a wakeup therefore delays delivery by at most
one heartbeat probe and cannot lose state.
"""

from __future__ import annotations

import asyncio
from collections import defaultdict
from collections.abc import Mapping
import threading
from typing import Any

from lib.conversation_sync.cursor import ConversationCursorError, decode_cursor, encode_cursor
from lib.log import get_logger
from lib.storage.commit_events import subscribe_committed_events


logger = get_logger(__name__)
_INVALIDATION_CONTRACT = "tofu.conversation-sync.invalidation/v1"
_COMMIT_CONTRACT = "storage.conversation-commit/v1"


def _scope(user_id: Any, conversation_id: str) -> tuple[str, str]:
    return str(user_id), str(conversation_id)


class ConversationWakeSubscription:
    def __init__(self, broker: "ConversationWakeBroker", key: tuple[str, str]) -> None:
        self._broker = broker
        self._key = key
        self._loop = asyncio.get_running_loop()
        self._queue: asyncio.Queue[None] = asyncio.Queue(maxsize=1)
        self._closed = False

    def _wake_on_loop(self) -> None:
        if self._closed or self._queue.full():
            return
        self._queue.put_nowait(None)

    def wake(self) -> None:
        if self._closed:
            return
        try:
            self._loop.call_soon_threadsafe(self._wake_on_loop)
        except RuntimeError:
            self.close()

    async def wait(self, timeout_seconds: float) -> bool:
        if self._closed:
            return False
        try:
            await asyncio.wait_for(self._queue.get(), timeout=timeout_seconds)
            return True
        except TimeoutError:
            return False

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._broker._unsubscribe(self._key, self)


class ConversationWakeBroker:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._subscriptions: dict[
            tuple[str, str], set[ConversationWakeSubscription]
        ] = defaultdict(set)
        self._latest_sequence: dict[tuple[str, str], int] = {}

    def subscribe(self, user_id: Any, conversation_id: str) -> ConversationWakeSubscription:
        key = _scope(user_id, conversation_id)
        subscription = ConversationWakeSubscription(self, key)
        with self._lock:
            self._subscriptions[key].add(subscription)
        return subscription

    def _unsubscribe(
        self, key: tuple[str, str], subscription: ConversationWakeSubscription
    ) -> None:
        with self._lock:
            subscribers = self._subscriptions.get(key)
            if not subscribers:
                return
            subscribers.discard(subscription)
            if not subscribers:
                self._subscriptions.pop(key, None)
                self._latest_sequence.pop(key, None)

    def wake(self, user_id: Any, conversation_id: str, sequence: int | None) -> None:
        key = _scope(user_id, conversation_id)
        with self._lock:
            subscribers = tuple(self._subscriptions.get(key, ()))
            if not subscribers:
                # A later subscriber performs a durable replay probe before
                # waiting, so retaining sequence hints for inactive
                # conversations would be pure unbounded process memory.
                return
            if sequence is not None:
                previous = self._latest_sequence.get(key, -1)
                if sequence <= previous:
                    return
                self._latest_sequence[key] = sequence
        for subscription in subscribers:
            subscription.wake()


broker = ConversationWakeBroker()


def _publish_invalidation(user_id: Any, event: Mapping[str, Any]) -> None:
    conversation_id = str(event.get("conversationId") or "")
    sequence = int(event.get("syncSeq") or 0)
    if not conversation_id or sequence <= 0:
        return
    broker.wake(user_id, conversation_id, sequence)
    try:
        from lib.agent_core.push import push_event

        push_event("notify", conversation_id, {
            "contract": _INVALIDATION_CONTRACT,
            "type": "conversation.invalidated",
            "conversationId": conversation_id,
            "cursorHint": encode_cursor(conversation_id, user_id, sequence),
            "userId": user_id,
        }, user_id=user_id)
    except Exception as exc:
        # Durable heartbeat probes still converge if the optional wake bus is
        # unavailable; log the transport fault without changing command truth.
        logger.warning(
            "Conversation invalidation publish failed conv=%s: %s",
            conversation_id[:12],
            exc,
        )


def _on_committed_events(carriers: tuple[Mapping[str, Any], ...]) -> None:
    newest: dict[tuple[str, str], tuple[Any, Mapping[str, Any]]] = {}
    for carrier in carriers:
        if carrier.get("contract") != _COMMIT_CONTRACT:
            continue
        event = carrier.get("event")
        user_id = carrier.get("userId")
        if not isinstance(event, Mapping) or user_id is None:
            continue
        conversation_id = str(event.get("conversationId") or "")
        key = _scope(user_id, conversation_id)
        previous = newest.get(key)
        if previous is None or int(event.get("syncSeq") or 0) > int(
            previous[1].get("syncSeq") or 0
        ):
            newest[key] = (user_id, event)
    for user_id, event in newest.values():
        _publish_invalidation(user_id, event)


def observe_delivery_frame(frame: Mapping[str, Any]) -> None:
    """Wake this replica for a validated cross-replica invalidation hint."""
    if (frame.get("channel") != "notify"
            or frame.get("contract") != _INVALIDATION_CONTRACT
            or frame.get("type") != "conversation.invalidated"):
        return
    conversation_id = str(frame.get("conversationId") or "")
    user_id = frame.get("userId")
    cursor = frame.get("cursorHint")
    if not conversation_id or user_id is None or not isinstance(cursor, str):
        return
    try:
        sequence = decode_cursor(conversation_id, user_id, cursor)
    except ConversationCursorError:
        logger.warning("Ignored malformed conversation invalidation cursor")
        return
    broker.wake(user_id, conversation_id, sequence)


_unsubscribe_storage = subscribe_committed_events(_on_committed_events)

# Route import happens during application assembly, after the global push hub
# exists.  Delivery listeners run on every replica, including frames received
# through Redis, so one committed write wakes all locally-held SSE streams.
from lib.agent_core.push import hub as _push_hub  # noqa: E402

_push_hub.add_delivery_listener(observe_delivery_frame)


__all__ = ["ConversationWakeBroker", "ConversationWakeSubscription", "broker"]
